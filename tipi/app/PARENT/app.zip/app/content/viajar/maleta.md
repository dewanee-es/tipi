# Tips para hacer tu maleta de forma óptima

Para la mayoría el verano es sinónimo de no estarse quieto. Ya sea el largo viaje de las tan ansiadas vacaciones o las pequeñas salidas de fin de semana, necesitaremos algún tipo de equipaje, ¿verdad? Además, no sólo en estos meses de calor podemos hacer escapadas, cualquier época del año es buena para desconectar y perderse unos días…

Y lo único imprescindible en todas estas situaciones es la maleta y la documentación. Para ello tenemos recomendaciones y consejos, algunos quizás obvios, para que no se te pase nada y evites cualquier problema. ¿Preparado?

![](list1v.jpg)

Desde ropa a la higiene íntima, del cuidado del pelo al dental, pasando por el calzado, la alimentación, un pequeño botiquín (con medicinas, si cabe), la documentación y la información del viaje,... Todo lo que se necesita en general para cualquier destino y todo lo requieres, en concreto, para tu destino.

La lista, obviamente, puede ser muy amplia, pero hay recursos para acortarla:

* **Según los días.** No te lleves 7 camisetas de tirantes o manga corta para un fin de semana.

* **Según el tiempo.** No pongas ropa gruesa o de abrigo si te vas a un lugar caluroso.

* **Según las intenciones.** Si no vas a la montaña, por ejemplo, no hace falta que te lleves botas de trekking (para caminar).

En definitiva, puede ser más sencillo de lo que crees.

Otro método para hacerlo es siguiendo… **los consejos de una madre**. Las madres suelen ser mujeres previsoras, siempre llevan cosas por si… por si hace frio, por si te manchas, por si hace calor, por si hay spa, playa o rio, por si tengo hambre, por si me duele la cabeza. En fin, un listado interminable de cosas posibles que hay que tener en cuenta. Pero, como todo, adáptate al destino que vas. Por días, por tiempo y por intenciones.

![](list2v.jpg)

Es conveniente estar informado con tiempo de los **seguros médicos necesarios** para viajar, especialmente en el **tema de vacunaciones y los consejos sobre medidas higiénicas y médicas** en el lugar que vamos a visitar.

Si viajamos por España no es necesario contratar seguros especiales, puesto que tenemos la Seguridad Social y nos atenderán sin más, pero si viajamos al extranjero sin seguro médico o tarjeta sanitaria europea puede que tengamos más problemas.

![](list3v.jpg)

Lo ideal es **cerciorarse con tiempo de la vigencia (o no) de nuestra documentación y de pedir con antelación los visados** que sean necesarios para nuestra ruta, pero no sería la primera vez que tenemos ese susto de… ¡Tengo caducada mi documentación!

Para que no nos pase es conveniente que cuando sepamos que tendremos que viajar, revisar cuanto antes DNI o pasaporte para tenerlos en vigencia. Y pedir visados si visitamos países que los requieren. Ser precavido, como dicen, no tiene precio.

![](list4v.jpg)

A algunos les va la aventura y la incertidumbre. No saber qué van a hacer o donde van a dormir o comer cada día, pero también hay otros, posiblemente la mayoría, que prefiere tener más claro que hacer, ver y donde dormir.

Y para eso están las guías turísticas y las webs de reserva. Por cierto, toda esta información debes tenerla en cuenta a la hora de hacer la maleta, porque no solo se trata de ropa, sino que debemos tener en cuenta estos consejos a la hora de prepararla.

![](list5v.jpg)

Primero de todo, tener claro el número de días que nos vamos y ser conscientes si somos de las personas que nos cambiamos 3 veces al día, dependiendo del momento, o tenemos suficiente con una prenda por día.

Y esto es muy importante porque puede cambiar mucho el tipo de maleta que llevaremos. Porque hasta quizás podemos ahorrarnos la facturación, con el ahorro consiguiente de tiempo, puede que de precio y seguro que de peso.

Pero sea o no muy grande, siempre vienen bien esos trucos para ahorrar espacio que abundan por internet. Os dejamos algunos de ellos: Como [enrollar la ropa](https://www.youtube.com/watch?v=tqzA2db1p30) y que ocupe menos, [doblarla en cruz](https://www.youtube.com/watch?v=OgeM7oYYE-I), o hacer paquetes de [vestuario por día](https://www.youtube.com/watch?v=myWpfJpVR_o).

## TIPS DE EMERGENCIA

### ¡Oh, no! Se me ha salido la crema en la maleta

Si no os ha pasado sois afortunados, porque cuando pasa suele manchar mucha ropa y no es nada agradable estrenar el viaje limpiando. Para evitarlo, usar bolsas con cierre hermético o si no utilizar una goma que sujete de arriba abajo el bote, “bloqueando” el tapón para que no haya ninguna fuga.

### ¿Qué hago con mi ropa sucia?

Es conveniente llevar varias bolsas de plástico sin usar. Entre otras cosas, para poner ropa sucia. Porque es muy lógico hacerlo cuando nos manchamos o practicamos algún tipo de deporte en nuestro viaje, pero también tenemos que separarla cuando nos hayamos puesto una o dos veces una prenda, aunque incluso siga oliendo a limpio. Y… ¿por qué? Así evitamos, al regresar, tener que lavarla y plancharla toda, porque es lo que tendremos que hacer si no la hemos separado convenientemente.

---

En fin, que pueden haber viajes tan diferentes como personas diferentes existen, pero todos tienen algo en común: tiene que hacer una maleta o una mochila antes de salir y puede que muchas más durante el trayecto.