# Viajar

> "Una vez al año ve a algún lugar en el que nunca hayas estado antes"
>
> -- <cite>Dalái Lama</cite>

## Información

* [Imprescindibles antes de viajar](requisitos.md)
* [Tips para hacer tu maleta de forma óptima](maleta.md)

## Destinos

* [España](destinos/espana.md)
* [Europa](destinos/europa.md)
* [África](destinos/africa.md)
* [América](destinos/america.md)
* [Asia](destinos/asia.md)

## Fecha

Recomendaciones según la fecha del viaje

### Septiembre

Hay que cambiar el concepto que tenemos de Septiembre y una buena forma de ello es dejar, si puedes, tus vacaciones para este mes. ¿Y por qué?

Porque así:

* Disfrutarás de todo el verano.

* Mantendrás la ilusión de las vacaciones más tiempo.

* Ahorrarás dinero viajando en una temporada más barata y…

Darás envidia a tus amigos y compañeros cuando el 31 de agosto vuelvan cabizbajos a su rutina (je, je, je…)

Te hacemos las **propuestas ideales para viajar en ese mes**:

* [Madeira](destinos/portugal.md#Madeira)
* [Menorca](destinos/espana.md#Menorca)
* [Sicilia](destinos/europa.md#Sicilia)
* [Munich](destinos/europa.md#Munich)
* [Vancouver](destinos/america.md#Vancouver)
* [Cabo Verde](destinos/africa.md#Cabo_Verde)