# Imprescindibles antes de viajar

Preparar un viaje es un modo de comenzar el mismo y dejarse llevar por la emoción ante esos días previos y los lugares por conocer. En ocasiones **se confunde la aventura con la imprevisión**, un error que se puede pagar muy caro. Es necesario ir preparado ante posibles desatinos, sobre todo si vas a visitar otros países. Por eso, te detallamos los imprescindibles para preparar tu viaje. Que no te impida viajar un carnet caducado o un visado sin solicitar. 

[TOC]

## Documento nacional de identidad (DNI)

El **DNI** es algo que siempre debes llevar encima, por obvio que parezca, las **autoridades te lo pueden solicitar **en cualquier momento. Por otro lado, te puede ser útil en muchísimas ocasiones e incluso para **viajar dentro de comunidades como la unión europea** será suficiente con llevar el DNI en la mayoría de destinos. No será necesario el pasaporte. Sin embargo siempre recomendamos llevar encima ambos.

**Recuerda** que lo puedes renovar con tres meses de antelación, y necesitas solicitar una cita previa, que suele demorar y a veces no encontramos hueco para la fecha del viaje, con lo que a veces toca ir de urgencia a la comisaría y aguantar largas colas.

## Pasaporte

¡Muy típico! Ese ya lo sé… Te sorprenderías de la gente que olvida su **pasaporte** a la hora de coger un vuelo. Pues bien, no hay **documento más importante** si vas a **viajar fuera de las fronteras** de tu comunidad. Sabemos que para **viajar por Europa**, por ejemplo, siendo miembro de ella no es necesario, sin embargo si lo es para muchos otros viajes. Así que asegúrate de **que lo llevas contigo y está vigente**.

Importante, aunque el aeropuerto cuenta con comisarías para expedirte uno de urgencia, no te recomendamos que pases por ese agobio, recuerda que las vacaciones son para descansar y no estresarte más.

## Visado

No se puede **viajar libremente** como a todos nos gustaría y algunos destinos exigen para entrar en él un visado. Consiste en **un sello en tu pasaporte**, conforme las **autoridades de dicho país te permiten la entrada**. ¡No lo olvides, puede ser un dolor de cabeza en algunas ocasiones!

## Seguro de viaje

Muy **recomendable en algunos viajes**, **imprescindible en otros**. Antes de aventurarte, deberás informarte sobre el destino y sus exigencias.

Si dispones de un seguro médico privado, infórmate sobre su cobertura y el teléfono al que deberás recurrir en caso de emergencia.

Si realizas tu viaje con una agencia suelen incluirlo, asegúrate de cuáles son sus coberturas. El precio de la asistencia sanitaria en algunos países es muy elevado, incluso de cientos de miles de euros; así que lo mejor es pagar un seguro para cubrirte en salud, nunca mejor dicho.

Si vas a viajar dentro de la Unión Europea, puedes solicitar la **Tarjeta Sanitaria Europea**, que acredita tu derecho a una cobertura médica pública.

## Carné de conducir nacional e internacional

Es un error pensar que con nuestro **carné de conducir** podremos hacerlo en cualquier destino, hay que solicitarlo a la Jefatura de tráfico. Si lo obtienes y lo acompañas siempre de tu carné original, no deberías tener problemas. ¡Disfruta conduciendo en otros países! Te facilitamos información para renovar el carnet de conducir nacional e internacional, aconsejable solicitarlo con un mes de antelación.

## Infórmate de la cobertura de tu tarjeta bancaria

Algunas **tarjetas de crédito** disponen de una **cobertura por pérdida de equipaje, retrasos en vuelos, robos**  y otro tipo de asistencias.

Para conocer la cobertura de tu tarjeta de crédito, solicita que te informen de la misma por escrito y llama al teléfono  que aparece en la misma para que te aclaren los puntos más dudosos.

Deberás asegurarte con tu banco de la **validez de estas en el extranjero** y de las posibles **comisiones** que te generarán en caso de usarlas. Una vez lo tengas todo claro, vía libre para gastar. ¡Con cuidado!

## Otras recomendaciones a tener en cuenta

### Si tienes hijos menores de edad

Para los más **pequeños** se recomienda siempre los siguientes **documentos**:

*   **Autorización de los padres**, del que esté ausente o del responsable o tutor legal. No es válida una autorización privada, tiene que ser pública realizada ante un notario o ante la Policía o [Guardia Civil](http://www.guardiacivil.es/es/servicios/permiso_salida_menores_extranjero/index.html). 
*   **Pasaporte o DNI**, según corresponda
*   **Documentación que pruebe la potestad** sobre los pequeños, como el libro de familia o certificados de nacimiento.

### Escanea los documentos de identidad

La pérdida de tu identificación puede ser un quebradero de cabeza, sobre todo si viajas al extranjero. Si bien no es válido como documento acreditativo para viajar, el tener escaneado tu pasaporte o DNI puede facilitar algunos trámites.

**Escanea** ambos documentos, **envíatelos por mail** y **descárgalos en tu móvil**. Así los tendrás disponibles en caso no disponer de internet.

Si tienes familia, haz lo mismo con tu libro de familia, es el único documento que puede acreditar que sois familia ante una emergencia u otro caso.

### Inscríbete en el registro de viajeros

Siempre es recomendable inscribirse en el [**registro de viajeros**](http://www.exteriores.gob.es/Portal/es/ServiciosAlCiudadano/SiViajasAlExtranjero/Paginas/InscribeteEnElRegistroDeViajeros.aspx).  En caso de una situación de emergencia en el país de destino, tendrán una información detallada de tu itinerario y será más fácil **localizarte**. Además, tendrás que poner un número de contacto de la persona a la que avisar en dichas circunstancias y tus familiares tendrán acceso directo a la información. Una vez que lo has hecho la primera vez solo tendrás que actualizar el itinerario y fecha cada vez que viajes.

### Certificado médico

Queremos darle la vital importancia que tiene a este pequeño **documento**. Si tienes alguna **enfermedad**, **insuficiencia** o **problema de salud crónico** debes llevar siempre encima un **certificado médico traducido al inglés**. Ten cuidado de que la traducción sea realizada por un profesional, ¡No utilices un traductor online!

### Vacunaciones

Si tu destino es un país lejano, infórmate sobre si necesitas recibir una **vacuna** o prescripción médica por alguna **epidemia puntual**. No merece la pena **convertir unas vacaciones en una convalecencia**.  

Procura hacerlo con la mayor antelación posible por dos razones. La primera es que algunas **vacunas requieren tiempo** para ser efectivas. La segunda es que estos centros suelen estar **saturados de citas** previas incluso un par de meses antes del viaje. Y asegúrate de que **no haces escala en un país con prescripciones médicas respecto al país de destino**.