# América

## Canadá

### Vancouver

![](vancouver.jpg)

Ubicada al suroeste de Canadá, **Vancouver** está considerada como una de las tres ciudades con mayor calidad de vida del mundo. Posee una gran diversidad étnica, ya que su población está formada por indios, coreanos, chinos, japoneses, iraníes… Es una ciudad dinámica, multicultural, hospitalaria, abierta, donde tienen cabida familias, jóvenes, gays, lesbianas, artistas…

Además, está rodeada de un espectacular entorno natural que ha sabido combinar a la perfección el mar con las montañas. No deberás perderte curiosidades como el Harbour Centre, es el tercer rascacielos más grande de Vancouver con una vista de 360º y una altura de 150 metros. Su acceso se hace por ascensores panorámicos acristalados. Conocido también como Vancouver Lookout, fue inaugurado en agosto de 1977 por el astronauta Neil Armstrong, que dejo su pisada del pie y una foto como testigo de su presencia. La torre funciona todo el año y es sede del campus de la Universidad de Simon Fraser.

O el Stanley Park, una antigua base militar, convertida en la actualidad en uno de los mayores parques urbanos del mundo, con más de 400 hectáreas, es más grande que el Central Park de Nueva York. Es un lugar muy buscado, por sus diversas actividades de entretenimiento.
