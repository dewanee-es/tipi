# Asia

## Malasia

### Kuala Lumpur

![La mejor comida en Kuala Lumpur se encuentra en los puestos callejeros, en el barrio de Bukit Bintang](http://www.lavanguardia.com/r/GODO/LV/p4/WebSite/2017/06/21/Recortada/img_lbernaus_20170621-121609_imagenes_lv_terceros_istock-458405173-k7uG--656x436@LaVanguardia-Web.jpg)

En el sudeste asiático, aparece **Kuala Lumpur (Malasia)**, con un precio medio de 1.253 euros por semana. Una urbe sorprendente llena de monumentos históricos, rascacielos, parques exuberantes, centros comerciales enormes, bulliciosos mercados callejeros y animadas noches, en la que conviven las culturas chinas, malayas e indios.

Posee su eje principal se llama el Triángulo de Oro que comprende **Bukit Bintang**, el lujoso barrio **KLCC** y el tradicional **Chinatown**. Aunque posee un exquisito centro colonial de casas baja y puestos callejeros donde se ofrecen auténticas delicias gastronómicas.

La urbe es ampliamente reconocida por numerosos lugares de interés, como las **torres Petronas** (los rascacielos gemelos más altos del mundo), el mercado de pulgas de **Petaling Street**, el pulmón verde de **Bukit Nanas Forest Reserve**, o la mezquita **Masjid Jamek** entre otras maravillas.

