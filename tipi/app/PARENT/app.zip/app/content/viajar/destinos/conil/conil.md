---
Coordenadas: 36°16′32″N 6°05′16″O
---
# Conil de la Frontera

Población: 22.297 habitantes (2016)
Distancia: 676 km de Madrid
Gentilicio: Conileño/ña
Sitio web: <www.conildelafrontera.es>

![](conil.jpg)

Conil de la Frontera es uno de los pueblos más pintorescos de la Costa de la Luz y uno de los destinos turísticos mas importante de la provincia de Cádiz. Un destino de pescadores con casas tradicionales, estrechas callejuelas, monumentos para visitar, amplias playas y otros lugares de alto valor ecológico e histórico.

No es un destino especialmente económico, pero merece la pena una parada si estás por la zona para perderte por sus calles o disfrutar de su animada vida desde alguna de sus múltiples terrazas mientras tomas algo. La Torre de Guzmán junto a su museo o la Iglesia de Santa Catalina son puntos estratégicos de esta localidad que no debes dejar de visitar.

En la zona del paseo suelen montar puestos de artesanía y la Playa de los Bateles dispone de una amplia extensión para relajarte o para realizar actividades deportivas. La oferta hotelera es buena pero al ser un pueblo no demasiado grande es recomendable realizar la reserva con tiempo.

## El Tiempo

<div id="c_4512af68426c00dc69c51bcf5b4a205c" class="alto"></div><script type="text/javascript" src="https://www.eltiempo.es/widget/widget_loader/4512af68426c00dc69c51bcf5b4a205c"></script>

* [Viento](https://www.eltiempo.es/cadiz-costa)
* [Olas](https://www.eltiempo.es/cadiz-costa/olas.html)
* [Temperatura del agua](https://www.eltiempo.es/cadiz-costa/temperatura-del-agua.html)

## Comer

### Heladerías

No olvidarse de tomar un helado en una de las muchas heladerías que pueblan Conil y que aparecen prácticamente en cada esquina.

## Noche

### [La Bobedita del Medio](https://www.facebook.com/Laboveditadelmedio/)

Calle José Tomás Borrego, 15
