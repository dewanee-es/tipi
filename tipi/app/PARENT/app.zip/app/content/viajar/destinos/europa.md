# Europa

## Alemania

### Leipzig

![](17_4.jpg)

Después de Berlín, Leipzig es conocida como la ciudad más hipster de Alemania. Tiene una vida cultural y nocturna muy agitada, con multitud de bares, restaurantes y teatros.

Es también conocida como la ciudad alemana de los libros ya que alberga la mayor feria de libros del país, además de tener sede de importantes casas editoriales, por lo que Leipzig es el paraíso de los amantes de la literatura.

Mejor época para visitar la ciudad: El verano es un estupendo momento para vivirla y pasearla.

### Munich

![](munich.jpg)

Si por casualidad decides retrasar un poco más las vacaciones o te quedan días disponibles en Octubre, esta es una opción divertida y en la que te lo pasarás muy bien.

Enclavada a los pies de los Alpes y surcada por el río Isar, **Munich** es la capital de la Región de Baviera y la tercera ciudad en importancia de Alemania. Está situada al sur del país, muy cerca de la frontera con Liechtenstein y Austria y está considerada como la meca de la cerveza. En Hofbrauhaus, la cantina más famosa del mundo, se sirven más de 10.000 litros diarios y es aquí, durante el mes de octubre, donde se celebra la fiesta de la cerveza más popular del mundo (**Oktoberfest**). Pero además de su gran oferta de ocio, Munich es una ciudad bella, arquitectónica, rica en historia… Destaca la iglesia gótica de Nuestra Señora, el auténtico emblema de la ciudad y el famoso jardín inglés, ideal para tomarse un respiro o alejarse por un rato de la cerveza.

## Austria

### Viena

![](17_13.jpg)

El centro histórico de Viena es una auténtica perla; se concentran todo tipo de riquezas, con notables ejemplos de arquitectura, escultura, pintura y, sobre todo, de música. Porque la capital de Austria lo es, al tiempo, de ese noble arte.

Aquí están dos de sus sedes fundamentales: la Staatsoper (la Ópera Estatal) y la Musikwerein, donde cada año, desde 1939, la Orquesta Filarmónica de Viena deleita al mundo con el Concierto de Año Nuevo.

Mejor época para visitar la ciudad: Visitar Viena durante los meses de verano es gozarla a más no poder, con hermosos paisajes llenos de toda la fuerza de la tierra que da vida a sus plantas, bosques y flores, entre días soleados pero frescos.

## Bélgica

### Namur

![](17_5.jpg)

La Ciudadela de Namur, uno de los castillos más grandes de Europa, ubicado estratégicamente para tener la zona vigilada ante los posibles invasores. Situada en la zona francófona de Bélgica, Valonia, Namur es la sede de las principales instituciones valonas y la puerta de entrada del bosque de Ardennen, una de las principales atracciones turísticas del país. Las ventajas de Namur es que, además de tener todos los privilegios de las grandes ciudades, no se encuentra abarrotada de turistas, por lo que es una buena alternativa a las siempre concurridas Bruselas y Brujas.

Organiza anualmente dos importantes festivales culturales: Festival des Arts Forains y Fêtes de la Wallonie.

Mejor época para visitar la ciudad: En verano el clima es ideal.

## Chipre

### Pafos

![](17_12.jpg)

En unos años Paphos se convirtió de una ciudad tranquila en un balneario grande y prestigioso, lleno de curiosidades y atrayente con su magnífica e inolvidable naturaleza. Está abierto el año entero, el mar permanece cálido, hace sol y casi no hay viento. Uno tendría que empezar a conocer esta ciudad con sus monumentos históricos y culturales, uno de los cuales es Pafos Medieval Fort

Mejor época para visitar la ciudad: La primavera y el otoño son las estaciones ideales para disfrutar de sol y la calma.

## Dinamarca

### Copenhague

![](17_15.jpg)

Quienes la comparan con alguna otra capital europea cometen un error además de una enorme injusticia, pues Copenhague tiene personalidad propia y atractivos más que de sobra para satisfacer los gustos de todo tipo de viajeros. Y, tópicos aparte, merece la pena visitarla en cualquier época del año.

Mejor época para visitar la ciudad: Todo el año, con toda rotundidad.

## Eslovaquia

### Bratislava

![](17_14.jpg)

Es una ciudad antigua muy hermosa, que encanta con el ambiente acogedor y la tranquilidad, que contrasta con la vida bulliciosa y activa de los habitantes actuales. En visitar todos los monumentos culturales y lugares de interés histórico tardarás algo más de un día, y será mejor empezar la exploración de la ciudad con su casco antiguo, Castillo de Bratislava.

Mejor época para visitar la ciudad: El mejor momento para visitar Bratislava es de mayo a septiembre.

## Eslovenia

### Liubliana

![](17_16.jpg)

Pequeña en comparación con otras grandes capitales europeas, conserva el encanto señorial de sus palacetes barrocos, toques Art Nouveau y un planteamiento urbanístico revolucionario, con zonas ajardinadas en el casco antiguo que se integran en una arquitectura ecléctica mezcla de clasicismo mediterráneo y funcionalidad.

Mejor época para visitarla ciudad: En general desde la primavera hasta el otoño es muy buena época para visitar la ciudad.

## Finlandia

### Helsinki

![](17_11.jpg)

Helsinki, la capital de Finlandia, es una vibrante ciudad costera de hermosas islas y grandes parques verdes. El ritmo de la ciudad es relajado, pero al mismo tiempo, activo tanto en términos de cantidad como de calidad de los restaurantes y clubes nocturnos.

Mejor época para visitar la ciudad: La mejor época para ir son los meses que van de mayo a septiembre que tienen días cálidos, largos y brillantes.

## Francia

### Marsella

![](17_8.jpg)

Marsella es una de las ciudades favoritas en Francia. Situada en un lugar estratégico, con uno de los principales puertos del Mediterráneo, la ciudad francesa ha bebido siempre de la influencia de otros pueblos y culturas de este mar, lo que le ha dado su carácter cosmopolita.

Mejor época para visitar la ciudad: En verano, la ciudad francesa es muy visitada, así que si quieres disfrutar del buen tiempo pero sin aglomeraciones, los mejores momentos para ir son entre abril - mayo y entre septiembre - octubre.

### París

## Grecia

### Mykonos

### Santorini

## Italia

### Sicilia

![](sicilia.jpg)

Situada al sur de Italia, **Sicilia** es la mayor isla del Mar Mediterráneo y la principal isla del país. Sus innumerables lugares de interés arqueológico, su mitología, su belleza natural, su riqueza histórica, sus playas, sus tradiciones socio-culturales y su excelente gastronomía han impulsado sobremanera el turismo en los últimos años.

En Sicilia encontrarás lugares como: __[Palermo](#Palermo)__, capital de la isla, Catania durmiendo bajo el volcán, Siracusa con la preciosa península Ortigia y el parque arqueológico, Agrigento y su valle de templos griegos, la tranquila Ragusa, Noto[ ](http://www.lasicilia.es/noto "Noto Barroco Siciliano")referente del barroco siciliano, Cefalu[ ](http://www.lasicilia.es/cefalu "Cefalu")con sus playas y su catedral normanda, Monreale mezcla de artesanía árabe y normanda, Taormina[ ](http://www.lasicilia.es/taormina "Taormina")y la panorámica del teatro romano con el Etna de fondo, Mesina[ ](http://www.lasicilia.es/mesina "Mesina")y el estrecho que separa la isla de Italia; y sus monumentos, y lugares más emblemáticos para visitar.

Pero también hay localidades de Sicilia más pequeñas pero no menos importantes de visitar como Aci, Castello, las Islas Eoilas con Lípari, Salina, Stromboli y Vulcano, Enna el ombligo de Sicilia, Marsala y sus vinos, la atemporal ciudad medieval de Erice, Corleone, las Islas Pelagias, Lampedusa...

Hmmm… notas el aroma a “El Padrino”?

**Que no te echen atrás “los rumores mafiosos”. Piensa en un buen vino, la playa, colores y a disfrutar. Y siempre con una sonrisa.**

#### Palermo

![](17_2.jpg)

La capital siciliana condensa en su superficie más de 2.700 años de historia, cultura, gastronomía con el mejor vino y un clima cálido todo el año. Es además muy famosa para los amantes del Street Food ya que cuenta con puestos de comida ambulante repartidos por toda Palermo. Su vida nocturna y cultural es de sobra conocida en Italia.

Mejor época para visitar la ciudad: En otoño, los días aún son cálidos, por lo que es un buen momento para descubrir Palermo.

## Países Bajos

### Amsterdam

### Den Bosch

![](17_7.jpg)

Esta ciudad holandesa destaca por su amplia oferta cultural que incluye museos, teatros y festivales como el Jazz in Duketown o el Bosch Parade. En la ciudad, también es posible encontrar el edificio de ladrillo más antiguo de los Países Bajos, De Moriaan, del siglo XIII, y que actualmente alberga la oficina de turismo y un pub.

(Y siempre, siempre que se pueda, aunque sólo sea por unas horas, Amsterdam)

Mejor época para visitar la ciudad: La primavera es el mejor momento para ir.

## Polonia

### Cracovia

![](17_10.jpg)

Cracovia es sin lugar a dudas una de las ciudades con más encanto de Polonia

Es una ciudad vibrante, llena de bares, restaurantes y clubs, así como museos, teatros y tiendas, y también con un fascinante casco histórico declarado Patrimonio de la Humanidad. Es una de las ciudades favoritas de los estudiantes para ir de Erasmus, por lo que el ambiente que se respira es muy joven.

Mejor época para visitar la ciudad: Primavera y otoño son los mejores momentos para ir, aunque si te gusta ver un paisaje nevado, también puedes visitar Cracovia en invierno.

### Varsovia

![Plaza del mercado con cafés y restaurantes en una hermosa mañana de sol en Varsovia](http://www.lavanguardia.com/r/GODO/LV/p4/WebSite/2017/06/21/Recortada/img_lbernaus_20170621-125437_imagenes_lv_terceros_istock-485070866-k7uG--656x438@LaVanguardia-Web.jpg)

**Varsovia (Polonia)** es una de las vacaciones más baratas de Europa a un precio de 883 euros por una semana. Una ciudad que desprende energía y belleza, que se asemeja más a una ciudad moderna europea que a la de la época comunista.

Posee **un casco antiguo muy peculiar** destruido durante la Segunda Guerra Mundial y, posteriormente, reconstruido hasta el más mínimo detalle lo cual posibilitó que el conjunto fuera declarado Patrimonio de la Humanidad. Aquí se impone un **paseo por el Camino Real**, considerada “la calle más hermosa de Polonia” que une el castillo Real con los palacios de Lazienki y de Wilanów.

Y en la parte nueva lleno de edificios modernos y rascacielos de la zona financiera que crece alrededor del **palacio de Cultura y la Ciencia** de 231 m de altura, sobresale el **centro comercial Terrazas Doradas**, cuya arquitectura futurista le ha convertido en el principal icono. Una zona llena de muchos bares y restaurantes con curiosas decoraciones

## Portugal

[Ver todos los destinos de Portugal](portugal.md)

## Reino Unido

### Brighton

![](17_3.jpg)

Uno de los destinos favoritos de los ingleses por sus playas, situada a una escasa hora en tren desde Londres.

Brighton es conocida por su carácter liberal, favoreciendo la creación de una importante comunidad LGTB en la ciudad, además de ser hogar de muchos artistas emergentes.

Mejor época para visitar la ciudad: En verano suele haber muchísima gente, así que una buena alternativa es el mes de mayo, cuando tiene lugar el Brighton Festival.

## Suecia

### Estocolmo

![](17_17.jpg)

Nacida de la tenacidad del hombre por unir islas en torno al lago Mälaren, la capital sueca conserva el encanto de un viejo barrio medieval sin renunciar a la nueva arquitectura. Diseño de vanguardia y jóvenes apasionados por el rock, pero también viejos pescadores de caña sobre sus puentes y playas de aguas cristalinas.

Mejor época para visitar la ciudad: Entre mayo y septiembre es el momento ideal.

## Suiza

### Lugano

![](17_9.jpg)

Fuera de Italia, la mayor ciudad con cultura del país transalpino es la suiza Lugano. Se sitúa a 8 kilómetros de la frontera italiana y durante siglos fue motivo de disputa entre Milán, Francia y los Estados Confederados Suizos, hasta que pasó a manos de éstos últimos. Es la ciudad más famosa del cantón Ticino, y es conocida por sus casinos, bancos y por la naturaleza que la rodea con un lago y las montañas de Monte Bré, Monte San Salvatore y Sighignola, por lo que es un destino ideal para los amantes de los deportes y las actividades al aire libre.

Mejor época para visitar la ciudad: En primavera, cuando florecen las camelias. (Y en cualquier momento para comprar relojes y/o chocolate belga)