# África

## Cabo Verde

![](cabo-verde.jpg)

Situadas en el Océano Atlántico, **las islas de Cabo Verde** son un pequeño paraíso totalmente por descubrir. Con una superficie de 4.033 kilómetros cuadrados está formada por diez islas volcánicas y 5 isletas.

Las islas (según su posición sobre el viento) están divididas en dos grupos: __Barlovento y Sotavento__.  
Las islas de Barlovento son las formadas por: Boa Vista, Sal, Santo Antao, Sao Nicolau, Sao Vicente y Santa Luzia (deshabitada).  
Las islas de Sotavento son las formadas por: Fogo, Brava, Maio, Santiago.

A pesar de ser un lugar de turismo relativamente reciente, nos sorprenderemos de lo que nos vamos a encontrar. Islas más africanas (Santiago) e islas más europeas (Sao Vicente) todas con sabor a nostalgia y ritmos caboverdianos.

En este paraíso lleno de contrastes, donde se mezcla las playas vírgenes con otras de arena blanca, hermosos acantilados con llanuras, donde en ocasiones los volcanes parecen emerger del abismo para mostrar toda su belleza, el viajero puede gozar de un sinfín de posibilidades como el buceo, senderismo, la pesca, windsurfing o simplemente ir a la playa y sentir “que se para el mundo”

## Marruecos

### Marrakech

**Marrakech (Marruecos) es el destino más barato fuera de Europa**, donde una semana de vacaciones puede costarle a los españoles alrededor de 750 euros. Y es que el exotismo de esta [ciudad](http://www.lavanguardia.com/viajes/20100922/54004344685/pasado-y-presente-en-marrakech.html) es un reclamo para los turistas.

![Los marroquíes y los turistas compran en las estrechas callejuelas cubiertas que forman el histórico mercado de la Medina en Marrakech](http://www.lavanguardia.com/r/GODO/LV/p4/WebSite/2017/06/21/Recortada/img_lbernaus_20170621-121611_imagenes_lv_terceros_istock-503654926-k7uG--656x459@LaVanguardia-Web.jpg)

La ciudad está dividida en dos partes: la zona antigua, **la Medina**, declarada patrimonio de la Humanidad, con sus _riads_, zocos y comercios típicos, y **la parte moderna fuera de sus murallas,** llena de hoteles de diseño y tiendas de lujo, son una combinación única de tradición y modernidad para ofrecer unas vacaciones de lujo.

No hay que perderse la parte antigua; la Medina y **la plaza de Jemaa El Fna** son visitas obligadas. En el interior nos espera un auténtico laberinto de callejuelas, y en el corazón, la plaza Jemaa El Fna con un espectáculo impagable; músicos, chilabas, encantadores de **serpientes, aguadores, dibujos de henna, vendedores,** carros, motos..., pero también se pueden encontrar propuestas más actuales de restaurantes y clubs en la parte nueva de la ciudad.

