# España

## Asturias

## Baleares

### Ibiza

### Formentera

### Menorca

![](menorca.jpg)

**La isla de Menorca** es sobradamente conocida por sus famosas e idílicas playas de aguas azul turquesa y arena blanca y es un auténtico paraíso para disfrutar del sol en familia. Siempre la recomendamos sin temor a equivocarnos.

Sus poco más de 200 km. de costa ofrecen al viajero infinidad de calas de una belleza descomunal. Pero aparte de descanso Menorca ofrece la posibilidad de realizar multitud de actividades acuáticas, visitar entrañables pueblos, descubrir sus monumentos megalíticos y saborear su cultura talayótica en un compendio de contrastes muy atractivo.

Es un destino ideal para viajar en verano aunque es cierto que durante el mes de agosto se produce un exceso de masificación de turistas que puede alterar sensiblemente el descanso buscado. Por eso, Septiembre  es la época idónea.

Ciudadela, Mahón, los acantilados, las puestas de sol… No puedes perderte nada, adornado además con una buena gastronomía y estupendas tiendas. No olvides la moda adlib.

## Canarias

### Tenerife

## [Conil de la Frontera / Costa de la Luz](conil/conil.md)

## Galicia

## Levante

### Benidorm

### Torrevieja

## Valencia

![](17_1.jpg)

Decir que Valencia es la ciudad de la paella y las Fallas sería quedarse muy corto, ya que la capital de la Comunidad Valenciana tiene muchísimo más que ofrecer. Para empezar, cuenta con una interesante vida cultural, con uno de los primeros Museos de Bellas Artes del país y los vestigios de los pasos de distintas culturas como la musulmana o la gótica en su arquitectura. Un claro ejemplo de esto lo podemos encontrar en las Torres de Quart, parte de la antigua muralla, o la Lonja de la Seda, importante edificio gótico declarado Patrimonio de la Humanidad por la Unesco. Segundo, por su clima, bueno todo el año, lo que la convierte en un destino ideal en cualquier estación. Y tercero, por su gastronomía, son muchos los deliciosos platos valencianos ¡Vale la pena probarlos todos!

Mejor época para visitar la ciudad: En marzo durante la celebración de las Fallas, pero cualquier fin de semana es perfecto para pasear por la ciudad y sus jardines.