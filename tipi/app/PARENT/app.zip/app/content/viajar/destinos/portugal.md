# Portugal

## Algarve

## Braga

![](17_6.jpg)

La tercera ciudad más poblada de Portugal y también la más antigua. Fue fundada durante la época del Megalítico, y como muchas otras ciudades del país, sufrió las invasiones de godos y musulmanes entre otros pueblos. Por la riqueza cultural que dejaron tras de sí y que se refleja en su arquitectura, Braga es también conocida como la Roma portuguesa.

Mejor época para visitar la ciudad: La Semana Santa bracarense es una de las más espectaculares del país, así que es la mejor excusa para descubrir la ciudad en todo su esplendor.

## Lisboa

## Madeira

![](madeira.jpg)

**Madeira** pertenece a nuestro querido país vecino, el país de Cristiano Ronaldo, de las toallas bordadas y de un magnífico bacalao.

Septiembre es un buen mes para visitarla porque el tiempo sigue siendo soleado, las temperaturas agradables y la mayor parte del turismo ya no está. Además, en este mes, se celebra el festival del vino de Funchal (la capital de la isla) y el de Estreito de Câmara de Lobos. Ambos conservan un gran sabor local y auténtico.

Visita Funchal y su “mercado dos Lavradores” con los puestos de frutas, verduras y flores. Disfruta de los jardines botánicos y los jardines tropicales del Monte Palacio. Para subir utiliza el funicular y para bajar el tobogán de madera que se inventó en 1850.

Acércate hasta de Câmara de Lobos y sus pueblos rodeados de viñedos. Desde aquí puedes llegar al cabo Girao (hay 10 km) que se encuentra a 589 m sobre el mar y es segundo acantilado marino más alto de Europa. Camina realizando una ruta de unas 2-3 horas hasta llegar a Vinte e cinco fontes o recorre la senda que comienza en Ponta de Sâo Lourenço entre acantilados.

Recorre la carretera de la costa norte hasta llegar a Porto Moniz donde te degustarás una mariscada “en condiciones”. Y viaja en barco hasta la isla de Porto Santo y relájate en la playa de arena dorada que tiene…¡17 km!

## Oporto

