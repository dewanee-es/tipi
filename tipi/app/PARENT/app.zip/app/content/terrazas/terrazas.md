![](terrazas.jpg)

Ha llegado ese momento del año, así que recorremos el país para encontrar las terrazas donde tomar el aperitivo, un vino después de trabajar o probar los mejores productos. Toma (buena) nota.

## [Terraza The Mint Roof, Hotel Vincci The Mint](http://www.vinccihoteles.com/es/Hoteles/Espana/Madrid/Vincci-The-Mint)

![](/uploads/wysiwyg/Terraza%20The%20Mint%20Roof.jpg)

En Madrid, damos la bienvenida a [Vincci The Mint](http://www.vinccihoteles.com/es/Hoteles/Espana/Madrid/Vincci-The-Mint). Su azotea se asoma a la Gran Vía y en ella se aloja un coqueto «foodtruck» (camión de comida callejera). Las vistas se aderezan con una agradable y relajada decoración playera, sesiones vermú y «afterwork». Streetfood, sí, pero en las alturas.

**¿Dónde?** Calle Gran Vía, 10, 28013 Madrid.

<span style="color:#FFD700"><span style="font-size:18px"><span style="font-family:tahoma,geneva,sans-serif">**2\. Rooftop, El Paracaidista concept store.**</span></span></span>

<span style="font-size:18px"><span style="font-family:tahoma,geneva,sans-serif"><span style="color:#ffcc33">**![](/uploads/wysiwyg/rooftop.jpg)**</span></span></span>

Es el último [gran multiespacio](http://www.elparacaidista.es/) que ha abierto en Madrid, en el barrio de Malasaña: tiendas, coctelería, cine, café y restaurante juntos en un **antiguo palacete** de la calle de La Palma. La coctelería **Cubanismo (**en la tercera planta) está inspirada en la Cuba decadente y todos sus muebles son antigüedades o proceden de rastrillos El restaurante **Parq (en el rooftop)**, está decorado con el papel pintado de **Batabasta** y los muebles de **Muji**. Mesas de madera, un jardín y los **tejados de Madrid al fondo.**

**¿Dónde?** Calle de la Palma, 10, 28004 Madrid.

<address><span style="font-family:tahoma,geneva,sans-serif"><span style="font-size:18px">**[<span style="color:#FFD700">3\. Terraza Arzábal, </span>](http://arzabal.com/)<span style="color:#FFD700">Museo Reina Sofía.</span>**</span></span></address>

<span style="font-family:tahoma,geneva,sans-serif"><span style="font-size:18px"><span style="color:#FFD700">**![](/uploads/wysiwyg/Terraza%20Arz%C3%A1bal.jpg)**</span></span></span>

Si el objetivo es **comer bien y al aire libre**: [este es el sitio](http://arzabal.com/). Una carta tradicional que en la terraza se amplía con carnes, pescados y verduras de temporada **cocinadas a la brasa**. 700 metros en horario ininterrumpido. **Desayunos incluidos**, para disfrutar de los días de primavera y verano. 

**¿Dónde?** Edificio Sabatini, Museo Reina Sofía, Calle de Santa Isabel, 52, 28012 Madrid.

<span style="color:#FFD700">**<span style="font-size:18px"><span style="font-family:tahoma,geneva,sans-serif">4\. Nice to meet you, Dear Hotel.</span></span>**</span>

<span style="color:#FFD700">**<span style="font-size:18px"><span style="font-family:tahoma,geneva,sans-serif">![](/uploads/wysiwyg/Dear%20Hotel3.JPEG)</span></span>**</span>

No es nuevo, pero el [Dear Hotel Madrid](http://www.dearhotelmadrid.com/es) sigue siendo un lugar relativamente desconocido para muchos en pleno centro de la ciudad. Sobre todo si hablamos de su **terraza, situada en la planta 14** y con unas **vistas panorámicas** dignas de competir por ser las mejores de la capital. Reservar mesa en el restaurante [_Nice to meet you,_](http://www.dearhotelmadrid.com/es/nice-to-meet-you) situado en este espacio, o simplemente tomarse algo allí es una buena excusa para descubrir el lugar y presumir de que conocemos uno de los nuevos mejores rincones de Madrid. Antes de que se ponga demasiado de moda, claro.

**¿Dónde?**<span style="color:#FFD700"> </span>Calle Gran Vía, 80, 28013 Madrid.

<span style="color:#FFD700">**<span style="font-size:18px"><span style="font-family:tahoma,geneva,sans-serif">5\. La cocina de San Antón</span></span>**</span>

<span style="color:#FFD700">**<span style="font-size:18px"><span style="font-family:tahoma,geneva,sans-serif">![](/uploads/wysiwyg/La-Cocina-de-San-Anton-Terraza.jpg)</span></span>**</span>

Cuenta con más de 300 metros de terraza para poder disfrutar de espectaculares vistas al cielo de Madrid y a las calles del encantador barrio de Chueca.

[La Cocina de San Antón](http://www.lacocinadesananton.com/) comprende también un restaurante interior con paredes de cristal que permiten disfrutar de las vistas y una terraza cubierta para quienes prefieran no lidiar con el astro rey. La carta está compuesta  principalmente por una  “cocina de mercado” con productos de temporada, también hace honor a la **imponente gastronomía ibérica de 5 Jotas**.

**¿Dónde? **Calle de Augusto Figueroa, 24, 28004 Madrid

<span style="color:#FFD700">**<span style="font-size:18px"><span style="font-family:tahoma,geneva,sans-serif">6\. Rooftop y Elephant Crocodile Monkey & Tet, Casa Bonay.</span></span>**</span>

<span style="color:#FFD700">**<span style="font-size:18px"><span style="font-family:tahoma,geneva,sans-serif">![](/uploads/wysiwyg/bd.jpg)</span></span>**</span>

En [Casa Bonay](http://casabonay.com/es/) las novedades vienen por partida doble. En las alturas, **inaugurarán de su azotea Rooftop**, y en los bajos, Elephant Crocodile Monkey & Tet, de Estanis Carenzo. La primera parte engloba un restaurante evolutivo con la ciudad y el entorno, centrado en el producto local y tapas para compartir. Tet se encuentra dentro del anterior y al mediodía se convierte en una taberna vietnamita con una parrilla.

**¿Dónde?** Gran Vía de les Corts Catalanes, 700, 08010 Barcelona.

<span style="font-size:18px"><span style="color:#FFD700"><span style="font-family:tahoma,geneva,sans-serif">**7\. Terraza y un cocktail bar, NH Collection Pódium.**</span></span></span>

![](/uploads/wysiwyg/NH%20Collection%20P%C3%B3dium.jpg)

La Ciudad Condal ha visto recientemente, asimismo, la reinauguración del [NH Collection Pódium](http://www.nh-hoteles.es/hotel/nh-collection-barcelona-podium), muy cerca de plaza de Cataluña. Este imponente edificio restaurado del siglo XIX cuenta con una azotea a su altura. Con cerca de **400 m2**, tiene **piscina exterior**, que abre durante los meses de verano. Junto a ella, **una terraza y un cocktail bar**, desde donde es posible disfrutar de parte de la propuesta gourmet del hotel (renovada por el chef Miguel Gaztelumendi), así como de una panorámica de Barcelona.

**¿Dónde?**<span style="color:#FFD700"> </span>Bailén 4-6, 08010 Barcelona.

<span style="color:#FFD700"><span style="font-size:18px"><span style="font-family:tahoma,geneva,sans-serif">**8\. Joël’s Oyster Bar, Mercado de la Boquería.**</span></span></span>

![](/uploads/wysiwyg/Oyster%20Bar2.jpg)

En el emblemático mercado barcelonés de La Boquería se encuentra [Joël’s Oyster Bar](https://www.facebook.com/joelsoysterbar/). El espacio plasma el mismo concepto que en Francia, donde este tipo de locales se encuentran en los mercados o bien al lado de los mismos productores. El ostricultor Joël Dupuch es el proveedor de las grandes protagonistas: las ostras. La propuesta incluye la fórmula de copa de vino más dos ostras por menos de 10 euros. Las referencias de la carta de vino blanco, cava y champanes -también por copas- cambian cada mes.

**¿Dónde?** La Rambla, 97, 08002 Barcelona.

<span style="color:#FFD700">**<span style="font-family:tahoma,geneva,sans-serif"><span style="font-size:18px">9\. El Mercader de l'Eixample, Ciudad Condal.</span></span>**</span>

![](/uploads/wysiwyg/El%20Mercader%20de%20Eixample.jpg)

 [El Mercader de l’Eixample](http://www.elmercaderdeleixample.com/) ocupa una casita en un pasaje con una **terraza encantadora** a la entrada. Es pequeñito. Apenas cogen **30 comensales**. Su propuesta gastronómica: producto ecológico, ¡tienen huerto propio!, para elaborar una cocina de Barcelona sin muchas florituras pero exquisita, con una carta estructurada con tres figuras geométricas: el círculo (tapas para tomar a cualquier hora del día), el cuadrado (platos) y hexágono (sugerencias del mes).

**¿Dónde?** Carrer de Mallorca, 239, 08008 Barcelona.

<span style="color:#FFD700">**<span style="font-size:18px"><span style="font-family:tahoma,geneva,sans-serif">10\. Restaurante Marina, Hotel Arts.</span></span>**</span>

![](/uploads/wysiwyg/restaurante%20Marina.jpg)

En la misma orilla del Mediterráneo nos encontramos con apetecibles renovaciones. El [Hotel Arts](http://www.hotelartsbarcelona.com/es) acaba de adoptar un **nuevo concepto gastronómico** en su restaurante Marina. Situado en los jardines del hotel, es la estrella de la temporada de verano y sirve comidas informales junto a la piscina. Su carta está compuesta por los platos más representativos de la cocina costera a nivel mundial, destacando los **productos del mar** e incorporando sabores de diferentes regiones del mundo como la **cocina peruana y asiática**, entre otras.

**¿Dónde?**Carrer de la Marina, 19-21, 08005 Barcelona.

**<span style="font-family:tahoma,geneva,sans-serif"><span style="color:#FFD700"><span style="font-size:18px">11\. Cargadero de Olabeaga, Ría de Bilbao.</span></span></span>**

![](/uploads/wysiwyg/Cargadero%20de%20Olabeaga.jpg)

En Bilbao se estrenará en apenas un mes el **C****argadero de Olabeaga**,  la **primera terraza acristalada y a techo descubierto situada sobre la ría**. El restaurante Astillero Euskalduna se hará cargo de las copas y los aperitivos. El espacio ha aprovechado los restos de la plataforma centenaria perteneciente al extinto cargadero Olabeaga, construido en 1894.

<span style="color:#FFD700">**<span style="font-size:18px"><span style="font-family:tahoma,geneva,sans-serif">12\. Antigua cueva de pescadores, Sa Cova.</span></span>**</span>

![](/uploads/wysiwyg/Passeig%20Santa%20agueda.jpg)

Por supuesto, nuestros archipiélagos no iban a ser menos. En Menorca, las mesas de Sa Cova casi rozan las olas. Sabor cien por cien menorquín que incorpora una **estética bucólica y romántica**, en el interior de una antigua **cueva de pescadores**. Se encuentra junto al hotel Barceló Hamilton Menorca, complejo al que pertenece. Solo está abierto hasta septiembre.

**¿Dónde?** Passeig Santa Àgueda, 6, 07720 Es Castell, Illes Balears.

<span style="color:#FFD700"><span style="font-size:18px"><span style="font-family:tahoma,geneva,sans-serif">**13\. Casa Club, The Ritz-Carlton Abama **</span></span></span>

![](/uploads/wysiwyg/casa%20club.jpg)

**The Ritz-Carlton Abama** amplía sus instalaciones y traslada el restaurante Abama Kabuki, uno de los mejores establecimientos españoles de comida japonesa, a la [Casa Club](http://www.ritzcarlton.com/en/hotels/spain/abama/dining/la-casa-club). El restaurante, en el que la novedad es la parrilla japonesa de carbón, está dividido en **sala, barra de sushi,** **Kabuki Bar y Kabuki Space**. Por su parte, el Kabuki Bar es un espacio exterior que forma parte del restaurante. En él podrás degustar toda la carta de sumillería, que se complementará con una oferta gastronómica. Será, sin duda, una de las terrazas del año. 

**¿Dónde?** Carretera General del Sur, TF-47, km 9, 38687 Guía de Isora Tenerife

Para finalizar nuestra ruta, una última propuesta que nos **mueve por tejados y terrazas urbanitas que normalmente no son accesibles al público**: [<span style="color:#FFD700">Med Rooftops</span>](http://www.medrooftops.com), que descubre terrazas absolutamente secretas, puesto que pertenecen a residencias privadas, durante solo unos días de junio, julio y septiembre. Este año, además de Madrid, se traslada a Nueva York, Lisboa y Londres.

**<span style="color:#FFD700"><span style="font-family:tahoma,geneva,sans-serif"><span style="font-size:18px">¡Ya no hay excusa para hacer siempre el mismo plan!</span></span></span>**

</div>

</div>