# Mojito

**Tiempo de preparación: 5 minutos**

![](mojito1.jpg)

## Ingredientes

**Para 400 ml**

* 1 lima por cada mojito
* 2 cucharadas de azúcar moreno
* 2 ramitas de hierbabuena
* hielo picado
* refresco de lima limóm, 7up o Sprite
* ron moreno (Barceló o Brugal)

## Videoreceta

[ver vídeo en YouTube](https://www.youtube.com/watch?v=kTgtinSI4ng)

## Preparación

1. Parte la lima en 8 trozos y agrégala a cada uno de los vasos en los que prepararás tu mojito (Una lima en cada vaso de mojito). Con el mortero, machaca bien la lima para sacarle todo el jugo.

2. Añade dos cucharadas de azúcar, la cantidad de azúcar es un poco a tu gusto.

3. Coloca unas hojas de hierbabuena en cada vaso de mojito y machaca un poco, lo justo para juntar los sabores, pero sin que se rompan las hojas. Si rompes las hojas te colapsarán la pajita con la que se bebe el mojito.

4. Añade una buena cantidad de hielo en el vaso de tu mojito, si es hielo picado mucho mejor. Vierte ron al gusto y, para finalizar, vierte el refresco de lima limón.

5. Con la cuchara, remueve el jugo de lima con hierbabuena de arriba a abajo. Verás que va cambiando de color. Ya lo tienes listo para disfrutar.

6. Puedes servirlo con una pajita gruesa.

Si lo preparas sin ron, no será un mojito, pero obtendrás un delicioso refresco de lima limón con hierbabuena. Está también riquísimo.

![](mojito2.jpg)