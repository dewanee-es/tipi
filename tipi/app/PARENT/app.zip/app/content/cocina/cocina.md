Cocina de verano:

* Bebidas:
	* [[Mojito]]
* Ensaladas
* Gazpachos
* Helados
* Recetas para la playa
* Recetas de verano