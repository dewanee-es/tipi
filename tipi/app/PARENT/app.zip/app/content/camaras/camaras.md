# Cámaras compactas y deportivas: registra todo lo que te pase este verano

Cada año, y a medida que la miniaturización avanza, los fabricantes logran incorporar increíbles prestaciones en pequeñas cámaras de bolsillo sorprendentemente potentes en cuanto a calidad y recursos.

Algunos dirán que con un Smartphone basta, y posiblemente sean los que priman simplemente la comodidad. Pero si te gusta realmente la fotografía, con un potente móvil no es suficiente. **Necesitarás una cámara y, hoy, existen modelos compactos que ocupan poco espacio** (caben en un bolsillo) **y mejoran ampliamente cualquier Smartphone del mercado.**

Entre ellas, te ofrecemos 5 recomendaciones, pero vamos más allá. Pensando en los largos baños en la playa del verano y en los amantes del deporte con vacaciones moviditas **también tenemos 4 opciones para que grabes y fotografíes bajo el agua** y todo lo que quieras. Un sinfín de posibilidades en la palma de tu mano, ¿no te atreves?

## Sony DSCRX100

Es una verdadera **cámara réflex camuflada en el cuerpo de una compacta**. Dentro de ellas, y fabricada en aluminio ligero, ésta es de un nivel superior. Con una apertura F1.8 extremadamente amplia y su fantástica lente, podrás crear **suaves efectos de desenfoque**.

__Valor añadido__: Tiene el modo ‘Noise Cancelling multisecuencia’ para **conseguir imágenes más nítidas con luz muy escasa**. Además del modo automático, igualmente cuenta con modos de disparo manuales como los que se usan en las réflex tradicionales.

![](cam1.jpg)

__Características principales:__

*   Sensor CMOS Exmor R tipo 1,0
*   Resolución: 20,2 Megapíxeles
*   Peso: 213 g
*   Velocidad disparo ráfaga: 10 fps
*   Zoom óptico: 3.6 x
*   Tamaño: 3,6 x 10,2 x 5,8 cm
*   Conectividad: No
*   Duración batería: 330 imágenes
*   Estabilizador de imagen: Sí
*   **Precio: 349 €. Puedes comprarla desde [este enlace](http://amzn.to/2rZumbb).**

## Panasonic DMC-TZ70EG-S

Perfecta por **tamaño** (para llevarla en el bolsillo), tiene un **buen zoom** que hará la delicia de los viajeros.

__Valor añadido__: Su **visor es excepcional** (electrónico y de conexión WIFI/NFC) y permite que la calidad de sus imágenes sean muy buenas, independientemente de la luminosidad con que se realicen. Tiene excelente añadidos como el formato RAW y el propio WIFI.

![](cam22.jpg)

__Características principales:__

*   Sensor MOS de alta sensibilidad
*   Resolución: 12.1 Megapíxeles
*   Peso: 218 g
*   Velocidad disparo ráfaga: 10 fps
*   Zoom óptico: 30x
*   Tamaño: 11,1 x 3,4 x 6,5 cm
*   Conectividad Wifi/NFC
*   Duración batería: 300 imágenes
*   Estabilizador de imagen: sí
*   **Precio: 295 €. Puedes comprarla desde [este enlace](http://amzn.to/2t0jKqR).**

## Canon PowerShot G9 X

Se presenta como una cámara de **rendimiento avanzado y funcionamiento sencillo**. Por propiedades puede competir perfectamente con compactas más potentes.

__Valor añadido__: Su **usabilidad, nada complicada** a pesar de tener características profesionales. Por ello **ofrece controles manuales** para que pueda ser dominada para amantes de la fotografía sin formación ni experiencia.

![](cam33.jpg)

__Características principales:__

*   Sensor: CMOS tipo 1,0 retro-iluminado
*   Resolución:  20.2 Megapíxeles
*   Peso: 209 g
*   Velocidad disparo ráfaga: 8.2 fps
*   Zoom óptico: 3x
*   Tamaño: 9,8 x 3,08 x 5,79 cm
*   Conectividad: conexión NFC, WIFI integrado y GPS a través de Smartphone
*   Duración batería: 220 imágenes
*   Estabilizador de imagen: sí
*   **Precio: 419 €. Puedes comprarla desde [este enlace](http://amzn.to/2t0xRwz).**

## Nikon Coolpix S7000

Destaca por su **diseño extraplano**. Tiene un **zoom óptico de 20 aumentos**, ampliable a 40x. Gracias a su **Wi-Fi integrada y NFC** resulta fácil y cómodo compartir imágenes.

__Valor añadido__: Con el objetivo que sea muy portable, es un modelo ligero y estilizado. Tan sólo tiene **27 mm de grosor y un peso de 161 g** (más ligera que un iPhone 6 Plus).

![](cam44.jpg)

__Características principales:__

*   Sensor: CMOS retroiluminado
*   Resolución: 16 Megapíxeles
*   Peso: 161 g
*   Velocidad disparo ráfaga: 9.2 fps
*   Zoom óptico: 20x
*   Tamaño: 10 x 2,7 x 6 cm
*   Conectividad: Sí Wifi/NFC
*   Duración batería: 210 imágenes
*   Estabilizador de imagen: sí (estabilizador híbrido)
*   **Precio: 299 €. Puedes comprarla desde [este enlace](http://amzn.to/2rupBCP).**

## Sony DSC-HX60

Este modelo de fantástico diseño forma parte de las mejores [cámaras compactas](http://buenosybaratos.es/electronica/camara-compacta/las-mejores-camaras-compactas/) Cyber-Shot de Sony que integran una impresionante potencia fotográfica para obtener fotos de gran calidad. Este modelo es una de las mejores en relación calidad-precio.

__Valor añadido__: Tiene un **zoom óptico de 30x** que es líder en el mercado, empaquetado en un cuerpo sorprendentemente pequeño. También cuenta con **control manual completo**.

![](cam55.jpg)

__Características principales:__

*   Sensor: CMOS Exmor R
*   Resolución: 20.4 Megapíxeles
*   Peso: 245 g
*   Velocidad disparo ráfaga: 10 fps
*   Zoom óptico: 30x
*   Tamaño: 10 x 10 x 10 cm
*   Conectividad: Sí Wifi/NFC
*   Duración batería: 380 imágenes
*   Estabilizador de imagen: Sí
*   **Precio: 238 €. Puedes comprarla desde [este enlace](http://amzn.to/2rpVmSv).**

Estas 5 opciones son para casi cualquier persona, pero si eres de los que les gustan los deportes y en vacaciones te mueves para practicarlos, necesitarás una cámara deportiva. Por ello te proponemos 4 de las opciones más relevantes que existen en el mercado…

## GoPro Hero4 Black (4K a 30 fps)

![](cam6.jpg)

Proporciona una de las **mejores calidades de video** de su categoría a resoluciones de hasta 4K a 30 cuadros por segundo o de 1080p a 120 cuadros por segundo.

*   **Precio: 461.10 €. Puedes comprarla desde [este enlace.](http://amzn.to/2s9x3VZ)**

## Sony Action Cam 4K FDR-X100V

![](/uploads/wysiwyg/cam7.jpg)

Ofrece la espectacular funcionalidad de **grabar vídeos en resolución** **4K a 30 fps**, unos 3840 x 2160\. Pero eso no es todo, porque esta máquina es capaz también de grabar **a Full HD** 1080p a 120fps  **o en ‘slow motion’**, a 240fps.

Además, esta cámara destaca por encima de las demás porque **cuenta con cuatro tecnologías** muy llamativas: **GPS, WiFi, NFC y SteadyShot**.

*   **Precio: 450 €. Puedes comprarla desde [este enlace](http://amzn.to/2s8XZoJ)**.

## iON Air Pro 3

![](cam8.jpg)

Aunque las carcasas de los modelos de Nilox y Rollei permiten sumergirlas hasta 100 metros de profundidad, el pódium lo completan **las cámaras de** **iON,** JVC y Panasonic, que pueden hacer **inmersiones sin carcasas adicionales a 15,** 5 y 3 m respectivamente.

*   **Precio: 135.76 €. Puedes comprarla desde [este enlace](http://amzn.to/2rugaDH).**

## Energy Sport Cam Pro

![](cam9.jpg)

Energy promete que su cámara es capaz de **grabar con calidad Full HD** **durante 3 horas,** con una batería de 1.130 mAh. Además, **su precio** es bastante más asequible que las demás.

*   **Precio: 108.53 €. Puedes comprarla desde [este enlace.](https://www.amazon.es/Energy-Sistem-Sport-Cam-Pro/dp/B00J21SR94)**

---

En definitiva, y para resumir, si tus objetivos no son profesionales las dos últimas opciones de estas cuatro cumplirán perfectamente tus expectativas. Las dos primeras, que son más caras, están pensadas para usos más avanzados, aunque todas ellas son cámaras con recursos, prestaciones y potencial a la altura de cualquier amante a la fotografía.
