This is where your content goes, you can do whatever you want and adjust your json according to it.
My personal configuration goes like the following

```
images/
pages/
posts/
```
