# README

<small>http://marmoush.com, http://ismailmarmoush.github.io</small>

This my personal blog, the contents are copyrighted under Creative Commons license, any other imported content are licensed under their original license.

As for the blog application [Sunstreet](https://github.com/m-io/sunstreet) itself it's licensed under  AGPL V3 license.

Feel free to clone this repo for test or publish but just don't forget to replace my content with yours.

Thanks,
Ismail Marmoush
